import logging
from openerp.osv import fields, osv
from openerp import api
_logger = logging.getLogger(__name__)
from openerp.exceptions import Warning as UserError

class stock_report_ext(osv.osv):
    
    _name='stock.report.ext'
    _columns = { 
                'location_id': fields.many2one('stock.location','Location'),
                'categ_id':fields.many2one('product.category','Product Category'),
                'product_id':fields.many2one('product.product','Product'),
                'company_id':fields.many2one('res.company','Company'),
                'lot_id': fields.many2one('stock.production.lot', 'Lot'),
                'is_with_lot':fields.boolean(string='With Lot')
               }
    
    def _get_default_company(self, cr, uid, context=None):
        if 'force_company' in context:
            return context['force_company']
        else:
            company = self.pool['res.users'].browse(cr, uid, uid,
                context=context).company_id
            return company.id if company else False
    
    _defaults={'company_id':_get_default_company}
    @api.multi
    def change_domain(self,which=None):
        if which=='category':
            self.product_id=None
        if which=='company':
            if self.product_id and self.company_id:
                if self.product_id.company_id!=self.company_id and self.product_id.company_id:
                    self.product_id=None
            if self.location_id and self.company_id:
                if self.location_id.company_id!=self.company_id and self.location_id.company_id:
                    self.location_id=None
        domain={'location_id':[('id','!=',None)],'product_id':[('id','!=',None)]}
        if self.company_id:
            domain['location_id']=['|',('company_id', '=', False),('company_id', '=', self.company_id.id)]
            domain['product_id']=['|',('company_id','=',self.company_id.id),('company_id','=',False)]
        if self.categ_id:
            domain['product_id'].append(('categ_id','=',self.categ_id.id))
        print 'Domian==',domain 
        return {'domain':domain}
    
    @api.onchange('company_id')
    def onchange_company_id(self):
        return self.change_domain('company')
       
    @api.onchange('categ_id')
    def onchange_categ_id(self):
        return self.change_domain('category')
    
    @api.multi
    def get_locations(self):
        all_child_locations=[]
        if self.location_id:
                for locs in self.env['stock.location'].search([('id','child_of',self.location_id.id)]):
                    if locs.usage!='view':
                        if self.company_id:
                            if not locs.company_id or locs.company_id==self.company_id:
                                all_child_locations.append(locs.id)
                        else:
                            all_child_locations.append(locs.id)    
        else:
            parent_locations=self.env['stock.location'].search([('usage','=','view')])
            for p_locs in parent_locations:
                for c_locs in self.env['stock.location'].search([('id','child_of',p_locs.id)]):
                    if c_locs.id not in all_child_locations and c_locs.usage!='view':
                        if self.company_id:
                            if not c_locs.company_id or c_locs.company_id==self.company_id:
                                all_child_locations.append(c_locs.id) 
                        else:
                            all_child_locations.append(c_locs.id)    
        return all_child_locations
        
    @api.multi
    def get_report(self):
        if self:
            all_child_locations=self.get_locations()
            print 'All Child Locs get_report=',all_child_locations
            ##########################################################
            locations=[]
            stock_quants=[]
            quants_locations=[]
            products=[]
            lots=[]
            categories=[]
            if self.product_id:
                products.append(self.product_id)
            if self.lot_id:
                lots.append(self.lot_id)
            if self.categ_id:
                categories.append(self.categ_id)
            ###########################################################
            if all_child_locations:
                domain_search=[]
                domain_search.append(('location_id','in',all_child_locations))
                if self.company_id and self._context.get('company_id',False):
                    domain_search.append(('company_id','=',self.company_id.id))
                if self.product_id:
                    domain_search.append(('product_id','=',self.product_id.id))
                if self.lot_id and self.is_with_lot:
                    domain_search.append(('lot_id','=',self.lot_id.id))
                elif self.is_with_lot:
                    domain_search.append(('lot_id','!=',None))
                qry_quant=self.env['stock.quant'].search(domain_search)
              
                #if no company selected (Using current company for fixing header logo)
                if not self.company_id:
                    self.company_id=self.env["res.users"].browse(self._uid).company_id.id
                print 'Qauery quant get_report=',qry_quant
                for quants in qry_quant:
                    if quants.location_id.id not in quants_locations:
                        if self.categ_id:
                            if self.categ_id==quants.product_id.categ_id:
                                quants_locations.append(quants.location_id.id)
                        else:    
                            quants_locations.append(quants.location_id.id)
                    if not self.product_id and quants.product_id not in products:
                        products.append(quants.product_id)
                    if not self.lot_id and quants.lot_id and quants.lot_id not in lots and self.is_with_lot:
                        lots.append(quants.lot_id)
                    if not self.categ_id and quants.product_id.categ_id not in categories:
                        categories.append(quants.product_id.categ_id)
                        ##############
                    if self.categ_id:
                        if quants.product_id.categ_id==self.categ_id :
                            stock_quants.append(quants)
                    else:
                        stock_quants.append(quants)
                   
                #remove locations that have no quants
                for loc in all_child_locations:
                    if loc in quants_locations:
                        locations.append(loc)
                report_locations=[]
                report_products=[]
                report_categories=[]
                report_lots=[]
                report_product_qty=[]
                no_of_quants=len(stock_quants)
                row_count=0    
                print 'Final Quants=',stock_quants
                print 'Final Locations=',locations
                if not stock_quants:
                    return [['no_stock']]
                print 'Locations=',locations
                print 'Products=',products
                for locs in locations:
                    for cat in categories:
                        for prod in products:
                            if prod.categ_id==cat:
                                quants_available=self.env['stock.quant'].search([('product_id','=',prod.id),('location_id','=',locs)])
                                #with lot report 
                                if self.is_with_lot and lots and quants_available:
                                    for lot in lots:
                                        duplicate_product_qty=0
                                        if lot.product_id==prod:
                                            domain=[('product_id','=',prod.id),('location_id','=',locs),('lot_id','=',lot.id)]
                                            quants_available=self.env['stock.quant'].search(domain)
                                            if quants_available:
                                                for quants in self.env['stock.quant'].search(domain):
                                                    row_count+=1
                                                    duplicate_product_qty+=quants.qty 
                                            if duplicate_product_qty!=0:
                                                report_lots.append(lot)
                                                report_locations.append(self.env['stock.location'].browse(locs))
                                                report_categories.append(cat)
                                                report_products.append(prod)
                                                report_product_qty.append(duplicate_product_qty)
                                            if row_count==no_of_quants:
                                                return [report_locations,report_categories,report_products,report_product_qty,len(locations),report_lots]
                                #without lot report
                                elif quants_available:
                                    duplicate_product_qty=0
                                    for quants in quants_available:
                                        row_count+=1
                                        duplicate_product_qty+=quants.qty 
                                    if duplicate_product_qty!=0:
                                        report_locations.append(self.env['stock.location'].browse(locs))
                                        report_categories.append(cat)
                                        report_products.append(prod)
                                        report_product_qty.append(duplicate_product_qty)
                                    if row_count==no_of_quants:
                                        return [report_locations,report_categories,report_products,report_product_qty,len(locations)]
            
    
    @api.multi
    def print_report(self):
        print 'reportttttttttttt'
        record_is_exist=self.search([('id','=',self.id)])
        if not record_is_exist:
            self=self.create({'company_id':self._context.get('company_id',False),'location_id':self._context.get('location_id',False),'product_id':self._context.get('product_id',False),'lot_id':self._context.get('lot_id',False),'is_with_lot':self._context.get('is_with_lot',False),'categ_id':self._context.get('categ_id',False)})
        old_report_ids=self.search([('id','!=',self.id)])
        print len(old_report_ids)
        if len(old_report_ids)>20:
            for old_reports in old_report_ids:
                old_reports.sudo().unlink()
        ##########################################
        if self:
            all_child_locations=self.get_locations()
            print 'All Child Locs Button=',all_child_locations
            if all_child_locations:
                domain_search=[]
                domain_search.append(('location_id','in',all_child_locations))
                if self.company_id and self._context.get('company_id',False):
                    domain_search.append(('company_id','=',self.company_id.id))
                if self.product_id:
                    domain_search.append(('product_id','=',self.product_id.id))
                if self.lot_id and self.is_with_lot:
                    domain_search.append(('lot_id','=',self.lot_id.id))
                elif self.is_with_lot:
                    domain_search.append(('lot_id','!=',None))
                qry_quant=self.env['stock.quant'].search(domain_search)
                print 'query quant=',qry_quant
                if qry_quant:
                    if not self.categ_id:
                        return {
                                    'type': 'ir.actions.report.xml',
                                    'report_name': 'stock_report_ext.report_stock_with_lot',
                                
                                }
                    else:
                        for quants in qry_quant:
                            if quants.product_id.categ_id==self.categ_id:
                                return {
                                    'type': 'ir.actions.report.xml',
                                    'report_name': 'stock_report_ext.report_stock_with_lot',
                                }
                        raise UserError('Out Of Stock ....')
                else:
                    raise UserError('Out Of Stock ....')
    @api.multi
    def no_stock(self):
        raise UserError('Out Of Stock ....')
